patch -p0 < oolite-gentoo.patch
sed -i -e 's/^\.PHONY: all$/.PHONY: .NOTPARALLEL all/' libjs.make
sed -i -e 's:.*STRIP.*:	true:' GNUmakefile.postamble
sed -i -e '/ADDITIONAL_OBJCFLAGS *=/aADDITIONAL_OBJCFLAGS += -fobjc-exceptions' GNUmakefile
sed "/void png_error/d" -i src/Core/Materials/OOPNGTextureLoader.m
